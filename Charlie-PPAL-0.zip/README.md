# Charlie PPAL-0

This archive is laid out to copy into the root of the existing Charlie repository.
It uses only the Python standard library and does not import Charlie's main loop.

```bash
python -m experiments.ppal.run --log ppal_demo.jsonl
python -m unittest discover -s tests -v
```

The demo plays a **scripted sequence of observations**: a rescue target, an enemy
blocking the route, a sudden close threat, clearance of the route, and the target
disappearing. `Forebrain` holds the rescue goal across the emergency. `Hindbrain`
chooses a route-clearing action, temporarily evades, then resumes. `Controller`
is a dry run. Each decision and next scripted observation is written as JSONL.

The actions do **not** cause the next observation. The log has no measured reward,
the enemy clearance is scripted, and there is no learning or camera recognition.
Next integration steps are an explicit controller transport, a camera observation
adapter, measured outcomes, and only then a learner. Review those interfaces
against the real RetroArch command vocabulary before connecting hardware.
