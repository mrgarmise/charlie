from pathlib import Path
import time,json,hashlib
from memory.evidence import EvidenceJournal
p=Path("/work/query-notebook-copy.sqlite3");before=hashlib.sha256(p.read_bytes()).hexdigest()
j=EvidenceJournal(p,read_only=True);rows=[]
for category in ("learning_context_reference","normal_meditation_result"):
 start=time.perf_counter();old=[r.id for r in j.records("observation") if r.data["payload"].get("category")==category];old_s=time.perf_counter()-start
 start=time.perf_counter();new=[r.id for r in j.category_records("observation",category)];new_s=time.perf_counter()-start
 assert old==new
 rows.append(dict(category=category,count=len(new),ordered_ids_identical=True,old_seconds=old_s,category_seconds=new_s))
j.close();assert hashlib.sha256(p.read_bytes()).hexdigest()==before
Path("/work/query-benchmark.json").write_text(json.dumps(dict(source_copy_sha256=before,read_only=True,original_untouched=True,rows=rows),indent=2)+"\n")
