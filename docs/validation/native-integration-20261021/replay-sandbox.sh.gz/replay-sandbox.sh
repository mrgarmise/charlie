#!/bin/bash
set -euo pipefail
task_code=${CHARLIE_AUDIT_CODE:-/home/five/charlie-native-integration-20261020}
task_evidence=/home/five/charlie-native-integration-evidence-20261020
mkdir -p "$task_evidence/home" "$task_evidence/tmp" "$task_evidence/state"
exec bwrap --tmpfs / --ro-bind /usr /usr --ro-bind /etc /etc --ro-bind /sys /sys \
 --symlink usr/lib /lib --symlink usr/bin /bin --symlink usr/sbin /sbin \
 --dir /run --dir /tmp --dev /dev --proc /proc --unshare-pid --die-with-parent \
 --ro-bind "$task_code" "$task_code" \
 --ro-bind /home/five/Projects/charlie/.git /home/five/Projects/charlie/.git \
 --ro-bind /home/five/Projects/charlie/.venv /runtime \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-terminal-restart/robotron-runs/development-20261011-221727/game-01/session-evidence.sqlite3 /inputs/j0.sqlite3 \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-ala2-bae659f60b0e/robotron-runs/marathon-20261009-021200/game-01/session-evidence.sqlite3 /inputs/j1.sqlite3 \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-ala2-bae659f60b0e/robotron-runs/development-20261009-024021/game-01/session-evidence.sqlite3 /inputs/j2.sqlite3 \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-marathon-camera-lifecycle/robotron-runs/development-20261011-203343/game-01/session-evidence.sqlite3 /inputs/j3.sqlite3 \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-agency-recovery/robotron-runs/development-20261011-183415/game-01/session-evidence.sqlite3 /inputs/j4.sqlite3 \
 --ro-bind /home/five/charlie-recovery/original-home/charlie-progress-watchdog/robotron-runs/development-20261011-212606/game-01/session-evidence.sqlite3 /inputs/j5.sqlite3 \
 --bind "$task_evidence" /work --chdir "$task_code" --clearenv \
 --setenv PATH /runtime/bin:/usr/bin:/bin --setenv HOME /work/home \
 --setenv XDG_DATA_HOME /work/home/.local/share --setenv XDG_CONFIG_HOME /work/home/.config \
 --setenv XDG_CACHE_HOME /work/home/.cache --setenv CHARLIE_LEARNING_STATE /work/state \
 --setenv TMPDIR /work/tmp --setenv PYTHONDONTWRITEBYTECODE 1 \
 --setenv PYTEST_DISABLE_PLUGIN_AUTOLOAD 1 --setenv PYTHONPATH "$task_code" \
 --setenv OPENBLAS_NUM_THREADS 1 --setenv OMP_NUM_THREADS 1 --setenv LC_ALL C.UTF-8 \
 /runtime/bin/python "$@"
