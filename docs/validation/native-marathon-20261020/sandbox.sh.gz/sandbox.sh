#!/bin/bash
set -euo pipefail
task_code=${CHARLIE_AUDIT_CODE:-/home/five/charlie-marathon-audit-20261020}
task_evidence=/home/five/charlie-marathon-audit-evidence-20261020
mkdir -p "$task_evidence/home" "$task_evidence/tmp" "$task_evidence/state"
exec bwrap --tmpfs / --ro-bind /usr /usr --ro-bind /etc /etc --ro-bind /sys /sys \
 --symlink usr/lib /lib --symlink usr/bin /bin --symlink usr/sbin /sbin \
 --dir /run --dir /tmp --dev /dev --proc /proc --unshare-pid --die-with-parent \
 --ro-bind "$task_code" "$task_code" \
 --ro-bind /home/five/Projects/charlie/.git /home/five/Projects/charlie/.git \
 --ro-bind /home/five/Projects/charlie/.venv /runtime \
 --bind "$task_evidence" /work --chdir "$task_code" --clearenv \
 --setenv PATH /runtime/bin:/usr/bin:/bin --setenv HOME /work/home \
 --setenv XDG_DATA_HOME /work/home/.local/share --setenv XDG_CONFIG_HOME /work/home/.config \
 --setenv XDG_CACHE_HOME /work/home/.cache --setenv CHARLIE_LEARNING_STATE /work/state \
 --setenv TMPDIR /work/tmp --setenv PYTHONDONTWRITEBYTECODE 1 \
 --setenv PYTEST_DISABLE_PLUGIN_AUTOLOAD 1 --setenv PYTHONPATH "$task_code" \
 --setenv OPENBLAS_NUM_THREADS 1 --setenv OMP_NUM_THREADS 1 --setenv LC_ALL C.UTF-8 \
 /runtime/bin/python "$@"
